function z = dClambdadx(lambda)
z = log2(lambda)./(1 + lambda).^2;
end